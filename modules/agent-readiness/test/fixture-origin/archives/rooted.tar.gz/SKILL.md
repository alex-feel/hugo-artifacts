---
name: fixture-archive
description: A fixture skill distributed as a gzip-compressed tar whose root is the skill directory.
---

# fixture-archive

A fixture skill archive. Its members exist so an unpacked copy looks like a real skill; the module never reads inside an archive, which is exactly the limitation this fixture demonstrates.
