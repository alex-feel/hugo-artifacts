---
name: fixture-archive-dot
description: A fixture skill archive whose root member is stored with a ./ prefix, which is still the root.
---

# fixture-archive-dot

A fixture skill archive. Some zip writers store a root member as ./NAME, and refusing that would be a false refusal.
