---
name: fixture-nested
description: A fixture skill wrapped in a directory, which is what every forge source archive produces and what a client must reject.
---

# fixture-nested

A fixture skill archive. Its members exist so an unpacked copy looks like a real skill; the module never reads inside an archive, which is exactly the limitation this fixture demonstrates.
