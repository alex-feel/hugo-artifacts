# Guide

A supporting file, carried inside the archive where the convention says it belongs.
