---
name: fixture-archive-zip
description: A fixture skill distributed as a zip whose root is the skill directory.
---

# fixture-archive-zip

A fixture skill archive. Its members exist so an unpacked copy looks like a real skill; the module never reads inside an archive, which is exactly the limitation this fixture demonstrates.
